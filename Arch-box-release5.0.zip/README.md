# [Unofficial]ArchLinux-DVD-midia-box
Modified on Isoheptane/arch-media-box  
I'm sorry that we only have Chinese version releases for now.  
English version will be made eventually.  

# Readme English Ver (Basically AI translated,but has been checked manually)

## Used Fonts  

Noto Sans  
Noto Sans CJK SC  
Roboto Mono  
DejaVu Sans  
Montserrat  
Inconsolata  
  
## Usage  
  
The box_source.png can be directly printed on 300g A3 art paper, but it needs to be adjusted to fit the A3 size.  
If the resolution is insufficient, you may use the original box_source.svg file. Since the paths in the file are not converted, you will need the fonts listed in the Used Fonts section.  
  
InstallationGuide provide instructions on how to install ArchLinux,there is no emphasis on aesthetics.  
If anyone is willing to help improve the design of InstallationGuide, please contact me.  
  
The intruction folder contains the user manual. The PNG files can be printed directly on A4 paper.  
  
## Disclaimer  

This work is licensed under both the CC BY-SA 3.0 and CC BY-SA 4.0 licenses.  
This is an unofficial project, and all dates mentioned hold no actual significance.  
  
# Readme中文版本  
  
## 使用字体  

Noto Sans  
Noto Sans CJK SC  
Roboto Mono  
DejaVu Sans  
Montserrat  
Inconsolata  
  
## 用法  

box_source.png可以直接使用300gA3铜版纸打印，需要适应A3大小  
如果觉得不够清晰可以使用原始的box_source.svg，文件没有转换路径所以需要上方字体列表的字体  
InstallationGuide.pdf和InstallationGuide.tex就是告诉你怎么安装ArchLinux,毫无美观性可言
如果有人愿意帮助美化InstallationGuide请联系我  
intruction是说明书，png可以直接用A4打印  
  
## 声明  

本作品采用 CC BY-SA 3.0 许可协议和 CC BY-SA 4.0 许可协议进行许可。  
本项目为非官方项目，所有日期均无实际意义。  
